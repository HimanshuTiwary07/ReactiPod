import React from 'react';

class Setting extends React.Component
{
    render()
    {
        return (
            <div className="screen-setting">
                <h1>Settings</h1>
                <div>
                <i class="fas fa-tools"></i>
                </div>
            </div>
        );
    }
};

export default Setting;