import React from 'react';

class Artists extends React.Component
{
    render()
    {
        return (
            <div className="artists-screen">
                <h1>
                    Artists
                </h1>
                <div>
                    <i className="far fa-smile"></i>
                </div>
            </div>
        )

    }
}

export default Artists;